// database/project constant
const DATABASE_SOURCE = 'do-airbyte-sh'; 

// schema/dataset constant input
//const SCHEMA_ALLOYDB = 'alloydb_'+ dataform.config.vars.input_environment;
//const SCHEMA_ALLOYDB_KB = 'alloydb_'+ dataform.config.vars.input_environment + '_kb';
const SCHEMA_MONGO = 'mongo_' + dataform.config.vars.input_environment;
//const SCHEMA_MONGO_BOT = 'mongo_kbchatbot_' + dataform.config.vars.input_environment;
const SCHEMA_SALESFORCE = 'salesforce';
const SCHEMA_CHARGEBEE_DOF = 'chargebee_dof' + dataform.config.vars.chargebee_suffix;
const SCHEMA_CHARGEBEE_DOH = 'chargebee_doh' + dataform.config.vars.chargebee_suffix;

// type chosen in config section
const TYPE_SOURCE = 'declaration';
const TYPE_OUTPUT = 'table'; 

module.exports = {
    DATABASE_SOURCE,
    SCHEMA_MONGO,
    SCHEMA_SALESFORCE,
    SCHEMA_CHARGEBEE_DOF,
    SCHEMA_CHARGEBEE_DOH,
    TYPE_OUTPUT,
    TYPE_SOURCE
};
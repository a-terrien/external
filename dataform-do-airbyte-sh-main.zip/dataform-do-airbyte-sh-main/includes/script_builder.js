//https://cloud.google.com/dataform/docs/reuse-code-includes?hl=fr#reference-nested-include --> Documentation sur comment construire une fonction sur Dataform

// Explication de ce que fait la fonction convert_string_to_json:
// Transforme input en string en un JSON lisible par BigQuery
//    - pas de valeur None -> replace by null
//    - pas de TRUE|FALSE ou True|False -> replace by true|false
//    - pas de simple quote mais des double quotes
// has a problem because it doesn't take into account the fact somme people will write down " inside their answer (such as the name)
function convert_string_to_json(input_string) {
    return `
        SAFE.PARSE_JSON(
            REPLACE(
                REPLACE(
                    REPLACE(
                        REPLACE(${input_string}, 'None', 'null'),
                        'True', 'true'
                    ),
                    'False', 'false'
                ),
                "\'", '"'
            )
        )
    `;
}

// Cette fonction permet de sortir un champ sous-imbriqué sous la forme d'une table contenant le champ et la clé primaire de la table de base.
// SORTIE: (SELECT id, sous-champ."value" 
//          FROM tab, 
//          UNNEST(tab.sous-champ) sous-champ)) AS tab_"value"
// Cette fonction ne fonctionne que pour les champs existant sous la forme suivante et dont la table a une clé primaire se nommant id: 	
// [{"name":"name1","value":"value1"},{"name":"name2","value":"value2"}, etc.]
function one_level_unnesting(input_table, input_field, input_name) {
    return `
    (
    SELECT id, CAST(JSON_VALUE(field.value, '$') AS STRING) AS ${input_name}
    FROM ${input_table} AS tab
    JOIN UNNEST(JSON_EXTRACT_ARRAY(tab.${input_field})) AS field
    WHERE JSON_VALUE(field.name, '$') = '${input_name}'
    ) AS tab_${input_name}
    `;
}

module.exports = {
    convert_string_to_json,
    one_level_unnesting
};
